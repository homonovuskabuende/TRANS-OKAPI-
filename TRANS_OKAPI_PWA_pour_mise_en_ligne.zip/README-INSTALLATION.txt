TRANS OKAPI — VERSION PWA

CONTENU
- index.html : application web
- manifest.webmanifest : identité installable de l’application
- service-worker.js : mise en cache de l’interface
- icon-192.png et icon-512.png : icônes

MISE EN LIGNE
Publier TOUS les fichiers de ce dossier à la racine d’un hébergement HTTPS. Le fichier index.html doit rester à la racine.

INSTALLATION ANDROID APRÈS PUBLICATION
1. Ouvrir l’adresse HTTPS de l’application dans Google Chrome.
2. Ouvrir le menu ⋮.
3. Choisir « Installer l’application » ou « Ajouter à l’écran d’accueil ».
4. Confirmer l’installation.

IMPORTANT
Cette préparation PWA ne crée pas un compte serveur et ne synchronise pas les réservations entre téléphones. Les données de cette version restent locales à l’appareil/navigateur. Il faut intégrer Firebase ou un autre backend sécurisé avant une exploitation réelle multi-utilisateurs. Le paiement mobile réel n’est pas connecté.
